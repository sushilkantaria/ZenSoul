import React from 'react';
import './Tunewithemotions.css';

const questions = [
  "How often do you take time to reflect on your feelings?",
  "How regularly do you feel overwhelmed by your emotions?",
  "How often do you understand why you feel a certain way?",
  "How often do you express your emotions through writing or journaling?",
  "How often do you practice self-compassion?",
  "How regularly do you acknowledge your emotions without judgment?",
  "How often do you feel comfortable sharing your true feelings with others?",
  "How often do you meditate or practice mindfulness to connect with your emotions?",
  "How frequently do you feel that your emotions guide your decisions?",
  "How often do you feel in control of your emotions?",
  "How regularly do you feel that your emotions are valid?",
  "How often do you take breaks when feeling emotionally overwhelmed?",
  "How frequently do you apologize when your emotions negatively impact others?",
  "How often do you use creative outlets to express your emotions?",
  "How regularly do you seek professional help to understand your emotions?",
  "How frequently do you feel emotionally balanced?",
  "How often do you avoid situations that might trigger negative emotions?",
  "How regularly do you set boundaries to protect your emotional well-being?",
  "How regularly do you forgive yourself for emotional mistakes?",
  "How frequently do you feel your emotions are aligned with your actions?"
];

const options = [
  "Never",
  "Occasionally",
  "Sometimes",
  "Often",
  "Always"
];

const Tunewithemotions = () => {
  return (
    <div className="quiz-container">
      <h1>Are You in Tune with Your Emotions?</h1>
      <form>
        {questions.map((question, index) => (
          <div className="quiz-question" key={index}>
            <p>{question}</p>
            <div className="quiz-options">
              {options.map((option, optIndex) => (
                <label key={optIndex}>
                  <input type="radio" name={`question-${index}`} value={option} />
                  {option}
                </label>
              ))}
            </div>
          </div>
        ))}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Tunewithemotions;
