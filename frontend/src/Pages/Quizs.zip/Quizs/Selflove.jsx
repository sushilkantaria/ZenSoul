import React, { useState } from 'react';
import './Selflove.css';

const SelfLoveQuiz = () => {
  const questions = [
    "I accept myself as I am.",
    "I take time to care for my physical health.",
    "I forgive myself for past mistakes.",
    "I set healthy boundaries in my relationships.",
    "I acknowledge my strengths and achievements.",
    "I speak to myself with positive affirmations.",
    "I make time for activities that I enjoy.",
    "I prioritize my mental well-being.",
    "I practice self-compassion during tough times.",
    "I take breaks when I need them.",
    "I nurture my body with healthy foods.",
    "I invest time in my personal growth.",
    "I surround myself with supportive people.",
    "I express my needs and desires.",
    "I let go of negative self-talk.",
    "I practice gratitude for who I am.",
    "I make decisions that are in my best interest.",
    "I trust myself to handle challenges.",
    "I value my opinions and perspectives.",
    "I feel deserving of love and respect."
  ];

  const options = ["Never", "Rarely", "Sometimes", "Usually", "Always"];
  const [responses, setResponses] = useState(Array(questions.length).fill(''));
  const [showResult, setShowResult] = useState(false);

  const handleOptionChange = (questionIndex, option) => {
    const newResponses = [...responses];
    newResponses[questionIndex] = option;
    setResponses(newResponses);
  };

  const handleSubmit = () => {
    setShowResult(true);
    // Handle result calculation here based on the responses
  };

  return (
    <div className="self-love-quiz-container">
      {!showResult ? (
        <div className="questions-container">
          {questions.map((question, index) => (
            <div key={index} className="question">
              <h4>{question}</h4>
              <div className="options">
                {options.map((option) => (
                  <label key={option} className="option-label">
                    <input
                      type="radio"
                      name={`question-${index}`}
                      value={option}
                      checked={responses[index] === option}
                      onChange={() => handleOptionChange(index, option)}
                    />
                    {option}
                  </label>
                ))}
              </div>
            </div>
          ))}
          <button className="submit-button" onClick={handleSubmit}>
            Submit
          </button>
        </div>
      ) : (
        <div className="result-container">
          <h2>Your Self-Love Score:</h2>
          {/* Add logic to display result based on responses */}
        </div>
      )}
    </div>
  );
};

export default SelfLoveQuiz;
