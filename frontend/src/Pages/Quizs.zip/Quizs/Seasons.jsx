import React, { useState } from 'react';
import './Seasons.css';

const SeasonQuiz = () => {
    const [answers, setAnswers] = useState({});

    const handleOptionChange = (questionNumber, value) => {
        setAnswers(prevAnswers => ({
            ...prevAnswers,
            [questionNumber]: value
        }));
    };

    const questions = [
        {
            question: "What’s your favorite type of weather?",
            options: ["Warm and sunny", "Cool and breezy", "Hot and dry", "Cold and snowy"]
        },
        {
            question: "Which color palette do you feel most drawn to?",
            options: ["Pastels", "Earth tones", "Bright and vibrant", "Cool and muted"]
        },
        {
            question: "What’s your ideal vacation spot?",
            options: ["A blooming garden or park", "A cozy cabin in the woods", "A sunny beach", "A snowy mountain resort"]
        },
        {
            question: "How do you prefer to spend your weekends?",
            options: ["Gardening or hiking", "Reading or visiting farmers' markets", "Going to the beach or attending festivals", "Skiing or staying cozy indoors"]
        },
        {
            question: "What’s your favorite type of clothing?",
            options: ["Light layers and floral prints", "Sweaters and boots", "Shorts and tank tops", "Coats and scarves"]
        },
        {
            question: "What’s your go-to drink?",
            options: ["Fresh lemonade or herbal tea", "Hot cocoa or chai latte", "Iced tea or cold brew coffee", "Warm cider or mulled wine"]
        },
        {
            question: "Which outdoor activity do you enjoy the most?",
            options: ["Walking through gardens or parks", "Strolling through colorful forests", "Swimming or surfing", "Ice skating or snowboarding"]
        },
        {
            question: "How do you feel about early mornings?",
            options: ["Energized and ready to go", "Calm and contemplative", "Excited to start the day", "Prefer to sleep in and stay cozy"]
        },
        {
            question: "What’s your favorite type of fruit?",
            options: ["Strawberries or cherries", "Apples or pears", "Watermelon or mango", "Oranges or pomegranates"]
        },
        {
            question: "What’s your preferred home decor style?",
            options: ["Light and airy with floral accents", "Warm and rustic with natural elements", "Bright and eclectic with bold colors", "Cozy and minimalist with cool tones"]
        },
        {
            question: "How do you handle stress?",
            options: ["Taking a nature walk or gardening", "Curling up with a book or baking", "Exercising or socializing with friends", "Meditating or having a warm drink by the fire"]
        },
        {
            question: "What’s your favorite scent?",
            options: ["Fresh flowers or cut grass", "Pumpkin spice or cinnamon", "Coconut or tropical fruits", "Pine or peppermint"]
        },
        {
            question: "What’s your favorite type of movie?",
            options: ["Romantic comedies or family films", "Mysteries or dramas", "Action or adventure", "Fantasy or holiday classics"]
        },
        {
            question: "How do you decorate your home for the season?",
            options: ["Fresh flowers and pastel colors", "Pumpkins and autumn leaves", "Seashells and bright colors", "Snowflakes and twinkling lights"]
        },
        {
            question: "What’s your favorite type of exercise?",
            options: ["Yoga or pilates", "Hiking or jogging", "Swimming or beach volleyball", "Skiing or indoor workouts"]
        },
        {
            question: "What’s your go-to comfort food?",
            options: ["Light salads or fruit smoothies", "Hearty soups or stews", "Grilled foods or ice cream", "Hot cocoa and cookies"]
        },
        {
            question: "How do you prefer to socialize?",
            options: ["Picnics or outdoor brunches", "Intimate dinner parties or coffee dates", "Beach parties or barbecues", "Cozy indoor gatherings or festive parties"]
        },
        {
            question: "What’s your ideal way to unwind?",
            options: ["Taking a nature walk or meditating", "Reading a book by the fireplace", "Sunbathing or attending a party", "Snuggling under a blanket with hot cocoa"]
        },
        {
            question: "How do you feel about outdoor activities?",
            options: ["Love exploring gardens and parks", "Enjoy hiking and bonfires", "Can’t get enough of the beach and water sports", "Adore skiing and snowball fights"]
        },
        {
            question: "What’s your favorite thing about each season?",
            options: ["Blossoming flowers and new growth", "Crisp air and colorful leaves", "Long days and vibrant activities", "Snowy landscapes and holiday spirit"]
        }
    ];

    return (
        <div className="quiz-container">
            <h1>Which Season Best Represents Your Personality?</h1>
            <form>
                {questions.map((q, index) => (
                    <div key={index} className="quiz-question">
                        <p>{q.question}</p>
                        <div className="quiz-options">
                            {q.options.map((option, i) => (
                                <label key={i}>
                                    <input
                                        type="radio"
                                        name={`question-${index}`}
                                        value={option}
                                        onChange={() => handleOptionChange(index, option)}
                                    />
                                    {option}
                                </label>
                            ))}
                        </div>
                    </div>
                ))}
            </form>
        </div>
    );
};

export default SeasonQuiz;
