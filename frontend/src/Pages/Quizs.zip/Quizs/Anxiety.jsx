import React, { useState } from 'react';
import './Anxiety.css';

const AnxietyQuiz = () => {
  const questions = [
    "Do you feel excessively worried about everyday situations?",
    "Do you avoid certain situations because they make you anxious?",
    "I find it very hard to unwind, relax, or sit still.",
    "Do you worry about things working out in the future?",
    "I have experienced shortness of breath or felt dizzy and unsteady at times.",
    "Feeling afraid as if something awful might happen.",
    "Have you been disinterested in activities and events you’ve previously enjoyed?",
    "Do you find it hard to concentrate on simple tasks such as reading the newspaper, or watching TV?",
    "Do you avoid social situations because you feel like you would be rejected or judged for being yourself?",
    "Do you worry about the same things over and over again or obsess a lot?",
    "Do you experience sudden feelings of panic?",
    "I have been irritable and easily become annoyed.",
    "I have felt nervous and on edge.",
    "I break into tears without apparent reason.",
    "I get tired quickly.",
    "I have racing thoughts.",
    "Do you worry about things that have already happened in the past?",
    "I have had difficulties with sleep (including waking early, finding it hard to go to sleep).",
    "Have you felt more tired than usual, even on days when you got adequate sleep?",
    "When facing an uncertain or dangerous situation, do you worry about it until the situation has been resolved or passed?"
  ];

  const options = ["Never", "Rarely", "Sometimes", "Usually", "Always"];
  const [responses, setResponses] = useState(Array(questions.length).fill(""));

  const handleOptionChange = (index, value) => {
    const newResponses = [...responses];
    newResponses[index] = value;
    setResponses(newResponses);
  };

  const handleSubmit = () => {
    // Logic to process the responses
    console.log(responses);
  };

  return (
    <div className="quiz-container">
      <h2>How Anxious Are You?</h2>
      <form onSubmit={handleSubmit}>
        {questions.map((question, index) => (
          <div key={index} className="question-block">
            <p>{question}</p>
            <div className="options-container">
              {options.map((option, i) => (
                <label key={i}>
                  <input
                    type="radio"
                    name={`question-${index}`}
                    value={option}
                    checked={responses[index] === option}
                    onChange={() => handleOptionChange(index, option)}
                  />
                  {option}
                </label>
              ))}
            </div>
          </div>
        ))}
        <button type="submit" className="submit-button">Submit</button>
      </form>
    </div>
  );
};

export default AnxietyQuiz;
