import React, { useState } from 'react';
import './Lovelang.css';

const LoveLanguageQuiz = () => {
  const [responses, setResponses] = useState({
    wordsOfAffirmation: 0,
    actsOfService: 0,
    receivingGifts: 0,
    qualityTime: 0,
    physicalTouch: 0,
  });

  const handleOptionChange = (language) => {
    setResponses(prevResponses => ({
      ...prevResponses,
      [language]: prevResponses[language] + 1,
    }));
  };

  const calculateResult = () => {
    const highestScore = Math.max(...Object.values(responses));
    const loveLanguage = Object.keys(responses).find(
      key => responses[key] === highestScore
    );
    return loveLanguage;
  };

  return (
    <div className="lovelang-quiz-container">
      <h1>What Is Your Love Language?</h1>

      <div className="LL-question">
        <h2>1. What makes you feel most loved?</h2>
        <label>
          <input type="radio" name="q1" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Hearing "I love you" or other compliments.
        </label>
        <label>
          <input type="radio" name="q1" onClick={() => handleOptionChange('actsOfService')} />
          Someone doing something kind or helpful for you.
        </label>
        <label>
          <input type="radio" name="q1" onClick={() => handleOptionChange('receivingGifts')} />
          Receiving a thoughtful gift.
        </label>
        <label>
          <input type="radio" name="q1" onClick={() => handleOptionChange('qualityTime')} />
          Spending uninterrupted time with someone.
        </label>
        <label>
          <input type="radio" name="q1" onClick={() => handleOptionChange('physicalTouch')} />
          A hug or physical affection.
        </label>
      </div>

      <div className="LL-question">
        <h2>2. What do you value most in a relationship?</h2>
        <label>
          <input type="radio" name="q2" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Verbal praise and encouragement.
        </label>
        <label>
          <input type="radio" name="q2" onClick={() => handleOptionChange('actsOfService')} />
          Practical help with tasks.
        </label>
        <label>
          <input type="radio" name="q2" onClick={() => handleOptionChange('receivingGifts')} />
          Surprise gifts and tokens of affection.
        </label>
        <label>
          <input type="radio" name="q2" onClick={() => handleOptionChange('qualityTime')} />
          Shared activities and conversations.
        </label>
        <label>
          <input type="radio" name="q2" onClick={() => handleOptionChange('physicalTouch')} />
          Physical closeness and touch.
        </label>
      </div>

      <div className="LL-question">
        <h2>3. How do you express love to others?</h2>
        <label>
          <input type="radio" name="q3" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Complimenting and affirming them.
        </label>
        <label>
          <input type="radio" name="q3" onClick={() => handleOptionChange('actsOfService')} />
          Doing things to help them out.
        </label>
        <label>
          <input type="radio" name="q3" onClick={() => handleOptionChange('receivingGifts')} />
          Giving them gifts.
        </label>
        <label>
          <input type="radio" name="q3" onClick={() => handleOptionChange('qualityTime')} />
          Spending time with them.
        </label>
        <label>
          <input type="radio" name="q3" onClick={() => handleOptionChange('physicalTouch')} />
          Physical affection, like hugs.
        </label>
      </div>

      <div className="LL-question">
        <h2>4. Which situation would make you feel most appreciated?</h2>
        <label>
          <input type="radio" name="q4" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Someone telling you how much they appreciate you.
        </label>
        <label>
          <input type="radio" name="q4" onClick={() => handleOptionChange('actsOfService')} />
          Someone helping you with a project.
        </label>
        <label>
          <input type="radio" name="q4" onClick={() => handleOptionChange('receivingGifts')} />
          Receiving a thoughtful present.
        </label>
        <label>
          <input type="radio" name="q4" onClick={() => handleOptionChange('qualityTime')} />
          Spending a whole day together doing something you love.
        </label>
        <label>
          <input type="radio" name="q4" onClick={() => handleOptionChange('physicalTouch')} />
          Being held or touched.
        </label>
      </div>

      <div className="LL-question">
        <h2>5. What's your ideal way to spend time with a loved one?</h2>
        <label>
          <input type="radio" name="q5" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Having deep conversations and sharing feelings.
        </label>
        <label>
          <input type="radio" name="q5" onClick={() => handleOptionChange('actsOfService')} />
          Working together on a project.
        </label>
        <label>
          <input type="radio" name="q5" onClick={() => handleOptionChange('receivingGifts')} />
          Exchanging gifts.
        </label>
        <label>
          <input type="radio" name="q5" onClick={() => handleOptionChange('qualityTime')} />
          Doing activities together.
        </label>
        <label>
          <input type="radio" name="q5" onClick={() => handleOptionChange('physicalTouch')} />
          Cuddling or holding hands.
        </label>
      </div>

      <div className="LL-question">
        <h2>6. What do you miss the most when you're away from your partner?</h2>
        <label>
          <input type="radio" name="q6" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Their words of encouragement.
        </label>
        <label>
          <input type="radio" name="q6" onClick={() => handleOptionChange('actsOfService')} />
          Their help with daily tasks.
        </label>
        <label>
          <input type="radio" name="q6" onClick={() => handleOptionChange('receivingGifts')} />
          The little gifts they give you.
        </label>
        <label>
          <input type="radio" name="q6" onClick={() => handleOptionChange('qualityTime')} />
          Spending time together.
        </label>
        <label>
          <input type="radio" name="q6" onClick={() => handleOptionChange('physicalTouch')} />
          Physical intimacy.
        </label>
      </div>

      <div className="LL-question">
        <h2>7. What gesture from a friend would mean the most to you?</h2>
        <label>
          <input type="radio" name="q7" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          A sincere compliment.
        </label>
        <label>
          <input type="radio" name="q7" onClick={() => handleOptionChange('actsOfService')} />
          Helping you with something important.
        </label>
        <label>
          <input type="radio" name="q7" onClick={() => handleOptionChange('receivingGifts')} />
          Giving you a meaningful gift.
        </label>
        <label>
          <input type="radio" name="q7" onClick={() => handleOptionChange('qualityTime')} />
          Hanging out with you for an afternoon.
        </label>
        <label>
          <input type="radio" name="q7" onClick={() => handleOptionChange('physicalTouch')} />
          Giving you a hug.
        </label>
      </div>

      <div className="LL-question">
        <h2>8. How do you like to show appreciation?</h2>
        <label>
          <input type="radio" name="q8" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          By telling someone how much you value them.
        </label>
        <label>
          <input type="radio" name="q8" onClick={() => handleOptionChange('actsOfService')} />
          By doing something for them.
        </label>
        <label>
          <input type="radio" name="q8" onClick={() => handleOptionChange('receivingGifts')} />
          By giving them a gift.
        </label>
        <label>
          <input type="radio" name="q8" onClick={() => handleOptionChange('qualityTime')} />
          By spending time with them.
        </label>
        <label>
          <input type="radio" name="q8" onClick={() => handleOptionChange('physicalTouch')} />
          By hugging them or holding hands.
        </label>
      </div>

      <div className="LL-question">
        <h2>9. What's the most meaningful compliment someone could give you?</h2>
        <label>
          <input type="radio" name="q9" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Praise for something you've done well.
        </label>
        <label>
          <input type="radio" name="q9" onClick={() => handleOptionChange('actsOfService')} />
          Saying thank you for your help.
        </label>
        <label>
          <input type="radio" name="q9" onClick={() => handleOptionChange('receivingGifts')} />
          Saying that they love a gift you gave them.
        </label>
        <label>
          <input type="radio" name="q9" onClick={() => handleOptionChange('qualityTime')} />
          Saying they enjoy spending time with you.
        </label>
        <label>
          <input type="radio" name="q9" onClick={() => handleOptionChange('physicalTouch')} />
          Saying they love being close to you.
        </label>
      </div>

      <div className="LL-question">
        <h2>10. Which action would mean the most to you?</h2>
        <label>
          <input type="radio" name="q10" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Receiving a handwritten note or message.
        </label>
        <label>
          <input type="radio" name="q10" onClick={() => handleOptionChange('actsOfService')} />
          Someone going out of their way to help you.
        </label>
        <label>
          <input type="radio" name="q10" onClick={() => handleOptionChange('receivingGifts')} />
          Someone surprising you with a gift.
        </label>
        <label>
          <input type="radio" name="q10" onClick={() => handleOptionChange('qualityTime')} />
          Someone spending quality time with you.
        </label>
        <label>
          <input type="radio" name="q10" onClick={() => handleOptionChange('physicalTouch')} />
          Someone giving you a long hug.
        </label>
      </div>

      <div className="LL-question">
        <h2>11. How do you like to receive apologies?</h2>
        <label>
          <input type="radio" name="q11" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Hearing the words "I'm sorry" with sincerity.
        </label>
        <label>
          <input type="radio" name="q11" onClick={() => handleOptionChange('actsOfService')} />
          Someone making amends by doing something to make up for it.
        </label>
        <label>
          <input type="radio" name="q11" onClick={() => handleOptionChange('receivingGifts')} />
          Receiving a peace offering or gift.
        </label>
        <label>
          <input type="radio" name="q11" onClick={() => handleOptionChange('qualityTime')} />
          Spending time together to talk it out.
        </label>
        <label>
          <input type="radio" name="q11" onClick={() => handleOptionChange('physicalTouch')} />
          A comforting touch or hug.
        </label>
      </div>

      <div className="LL-question">
        <h2>12. What would make you feel most appreciated by a partner?</h2>
        <label>
          <input type="radio" name="q12" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Them telling you how much they value you.
        </label>
        <label>
          <input type="radio" name="q12" onClick={() => handleOptionChange('actsOfService')} />
          Them helping you with something important.
        </label>
        <label>
          <input type="radio" name="q12" onClick={() => handleOptionChange('receivingGifts')} />
          Them giving you a thoughtful gift.
        </label>
        <label>
          <input type="radio" name="q12" onClick={() => handleOptionChange('qualityTime')} />
          Them spending time with you.
        </label>
        <label>
          <input type="radio" name="q12" onClick={() => handleOptionChange('physicalTouch')} />
          Them being affectionate.
        </label>
      </div>

      <div className="LL-question">
        <h2>13. How do you like to comfort someone when they're upset?</h2>
        <label>
          <input type="radio" name="q13" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Offering words of support and understanding.
        </label>
        <label>
          <input type="radio" name="q13" onClick={() => handleOptionChange('actsOfService')} />
          Doing something helpful for them.
        </label>
        <label>
          <input type="radio" name="q13" onClick={() => handleOptionChange('receivingGifts')} />
          Giving them something to cheer them up.
        </label>
        <label>
          <input type="radio" name="q13" onClick={() => handleOptionChange('qualityTime')} />
          Spending time with them and listening.
        </label>
        <label>
          <input type="radio" name="q13" onClick={() => handleOptionChange('physicalTouch')} />
          Giving them a hug or patting their back.
        </label>
      </div>

      <div className="LL-question">
        <h2>14. What's your preferred way to celebrate a special occasion?</h2>
        <label>
          <input type="radio" name="q14" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Hearing or reading heartfelt messages.
        </label>
        <label>
          <input type="radio" name="q14" onClick={() => handleOptionChange('actsOfService')} />
          Having someone take care of everything for you.
        </label>
        <label>
          <input type="radio" name="q14" onClick={() => handleOptionChange('receivingGifts')} />
          Receiving gifts from loved ones.
        </label>
        <label>
          <input type="radio" name="q14" onClick={() => handleOptionChange('qualityTime')} />
          Spending the day with someone special.
        </label>
        <label>
          <input type="radio" name="q14" onClick={() => handleOptionChange('physicalTouch')} />
          Enjoying a hug, kiss, or other physical closeness.
        </label>
      </div>

      <div className="LL-question">
        <h2>15. What would make your day better?</h2>
        <label>
          <input type="radio" name="q15" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Receiving a kind and encouraging message.
        </label>
        <label>
          <input type="radio" name="q15" onClick={() => handleOptionChange('actsOfService')} />
          Someone helping you with a task or chore.
        </label>
        <label>
          <input type="radio" name="q15" onClick={() => handleOptionChange('receivingGifts')} />
          Receiving a surprise gift.
        </label>
        <label>
          <input type="radio" name="q15" onClick={() => handleOptionChange('qualityTime')} />
          Spending quality time with a friend or loved one.
        </label>
        <label>
          <input type="radio" name="q15" onClick={() => handleOptionChange('physicalTouch')} />
          A warm hug from someone you care about.
        </label>
      </div>

      <div className="LL-question">
        <h2>16. What's the best way for someone to make you feel loved?</h2>
        <label>
          <input type="radio" name="q16" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Telling you how much they love you.
        </label>
        <label>
          <input type="radio" name="q16" onClick={() => handleOptionChange('actsOfService')} />
          Doing something for you without being asked.
        </label>
        <label>
          <input type="radio" name="q16" onClick={() => handleOptionChange('receivingGifts')} />
          Surprising you with a gift.
        </label>
        <label>
          <input type="radio" name="q16" onClick={() => handleOptionChange('qualityTime')} />
          Planning a special day together.
        </label>
        <label>
          <input type="radio" name="q16" onClick={() => handleOptionChange('physicalTouch')} />
          Giving you a lot of physical affection.
        </label>
      </div>

      <div className="LL-question">
        <h2>17. How do you like to end a day spent with someone you love?</h2>
        <label>
          <input type="radio" name="q17" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          By sharing what you appreciate about them.
        </label>
        <label>
          <input type="radio" name="q17" onClick={() => handleOptionChange('actsOfService')} />
          Doing something to help them unwind.
        </label>
        <label>
          <input type="radio" name="q17" onClick={() => handleOptionChange('receivingGifts')} />
          Giving them a small token of appreciation.
        </label>
        <label>
          <input type="radio" name="q17" onClick={() => handleOptionChange('qualityTime')} />
          Talking or enjoying time together before bed.
        </label>
        <label>
          <input type="radio" name="q17" onClick={() => handleOptionChange('physicalTouch')} />
          With a hug, kiss, or cuddle.
        </label>
      </div>

      <div className="LL-question">
        <h2>18. What's the most thoughtful thing someone could do for you?</h2>
        <label>
          <input type="radio" name="q18" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Write a heartfelt note or message.
        </label>
        <label>
          <input type="radio" name="q18" onClick={() => handleOptionChange('actsOfService')} />
          Offer to help you with something important.
        </label>
        <label>
          <input type="radio" name="q18" onClick={() => handleOptionChange('receivingGifts')} />
          Surprise you with a gift.
        </label>
        <label>
          <input type="radio" name="q18" onClick={() => handleOptionChange('qualityTime')} />
          Spend time with you doing something you both enjoy.
        </label>
        <label>
          <input type="radio" name="q18" onClick={() => handleOptionChange('physicalTouch')} />
          Give you a comforting touch or hug.
        </label>
      </div>

      <div className="LL-question">
        <h2>19. What would you appreciate most on a tough day?</h2>
        <label>
          <input type="radio" name="q19" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Hearing words of encouragement and support.
        </label>
        <label>
          <input type="radio" name="q19" onClick={() => handleOptionChange('actsOfService')} />
          Someone taking care of something for you.
        </label>
        <label>
          <input type="radio" name="q19" onClick={() => handleOptionChange('receivingGifts')} />
          Receiving a gift that shows someone is thinking of you.
        </label>
        <label>
          <input type="radio" name="q19" onClick={() => handleOptionChange('qualityTime')} />
          Spending time with a close friend or loved one.
        </label>
        <label>
          <input type="radio" name="q19" onClick={() => handleOptionChange('physicalTouch')} />
          Receiving a hug or some kind of physical comfort.
        </label>
      </div>

      <div className="LL-question">
        <h2>20. What's the best way to start your day?</h2>
        <label>
          <input type="radio" name="q20" onClick={() => handleOptionChange('wordsOfAffirmation')} />
          Hearing or reading something inspiring.
        </label>
        <label>
          <input type="radio" name="q20" onClick={() => handleOptionChange('actsOfService')} />
          Having someone do something to help you start the day smoothly.
        </label>
        <label>
          <input type="radio" name="q20" onClick={() => handleOptionChange('receivingGifts')} />
          Receiving a small morning surprise or gift.
        </label>
        <label>
          <input type="radio" name="q20" onClick={() => handleOptionChange('qualityTime')} />
          Spending time with a loved one before starting your day.
        </label>
        <label>
          <input type="radio" name="q20" onClick={() => handleOptionChange('physicalTouch')} />
          Getting a morning hug or kiss.
        </label>
      </div>

      <div className="submit-btn">
        <button type="submit">See Your Love Language</button>
      </div>
    </div>
  );
}

export default LoveLanguageQuiz;
