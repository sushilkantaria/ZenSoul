import React, { useState } from 'react';
import './Anger.css';

const Anger = () => {
    const questions = [
        "How often do you find yourself yelling or raising your voice when you're upset?",
        "How frequently do you get irritated by minor inconveniences?",
        "When someone disagrees with you, how often do you feel anger building up inside you?",
        "How often do you feel like you need to leave a situation to avoid losing your temper?",
        "When someone makes a mistake at work or school, how often do you feel frustrated?",
        "How frequently do you argue with family members?",
        "How often do you get upset when things don’t go as planned?",
        "How often do you feel angry when someone interrupts you?",
        "How frequently do you lose your temper when playing competitive games or sports?",
        "How often do you find yourself holding grudges?",
        "How often do you get upset when someone doesn't understand what you're saying?",
        "When someone doesn't follow through on a promise, how often do you feel anger?",
        "How often do you find yourself thinking about past events that made you angry?",
        "When someone criticizes you, how often do you feel angry?",
        "How frequently do you argue with friends over small things?",
        "How often do you feel angry when someone blames you for something you didn’t do?",
        "How often do you feel your heart rate increase when you get angry?",
        "How often do you find it hard to forgive someone who has wronged you?",
        "How frequently do you get angry when someone takes your things without asking?",
        "How frequently do you find yourself regretting things you said or did in anger?"
    ];

    const options = ["Never", "Occasionally", "Sometimes", "Often", "Always"];

    const [responses, setResponses] = useState(Array(questions.length).fill(null));

    const handleOptionChange = (questionIndex, option) => {
        const newResponses = [...responses];
        newResponses[questionIndex] = option;
        setResponses(newResponses);
    };

    const handleSubmit = () => {
        console.log('User responses:', responses);
        // Logic to calculate and display results can be added here
    };

    return (
        <div className="anger-quiz">
            <h1>Measure Your Anger Thermometer</h1>
            {questions.map((question, index) => (
                <div key={index} className="anger-question-block">
                    <h3>{index + 1}. {question}</h3>
                    <div className="anger-options">
                        {options.map((option, optIndex) => (
                            <label key={optIndex}>
                                <input 
                                    type="radio" 
                                    name={`question-${index}`} 
                                    value={option}
                                    checked={responses[index] === option}
                                    onChange={() => handleOptionChange(index, option)}
                                />
                                {option}
                            </label>
                        ))}
                    </div>
                </div>
            ))}
            <button onClick={handleSubmit}>Submit</button>
        </div>
    );
};

export default Anger;
