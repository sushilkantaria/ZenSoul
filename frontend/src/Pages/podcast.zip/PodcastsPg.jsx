import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import './PodcastsPg.css';

const PodcastsPg = () => {
  const handpickedRef = useRef(null);

  useEffect(() => {
    // GSAP animation for the scrolling cards
    gsap.to(".podcast-individualpg-card-row", {
      x: "-100%",
      repeat: -1,
      duration: 20,
      ease: "linear"
    });

    // GSAP animation for the visibility of "Handpicked" text
    const handleMouseMove = (e) => {
      if (e.clientY < window.innerHeight / 2) {
        gsap.to(handpickedRef.current, {
          opacity: 1,
          y: 0,
          duration: 1
        });
      } else {
        gsap.to(handpickedRef.current, {
          opacity: 0,
          y: 50,
          duration: 1
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="podcast-individualpg-container">
      <div className="podcast-individualpg-heading-section">
        <h1 className="podcast-individualpg-main-heading">
          Endless topics. Endlessly engaging.
        </h1>
        
        <p ref={handpickedRef} className="podcast-individualpg-handpicked-text">
          Handpicked. For every individual.
        </p>
      </div>
      <div className="podcast-individualpg-cards-section">
        <div className="podcast-individualpg-card-row">
          {[...Array(5)].map((_, index) => (
            <div key={index} className="podcast-individualpg-card">
              <img src={`https://placehold.co/300x400?text=Podcast+${index + 1}`} alt={`Podcast ${index + 1}`} className="podcast-individualpg-card-img" />
              <h3 className="podcast-individualpg-card-heading">Podcast {index + 1}</h3>
              <button className="podcast-individualpg-listen-now-button">Listen Now</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PodcastsPg;
